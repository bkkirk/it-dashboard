using BlazorDashboard.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ─── Services ────────────────────────────────────────────────────────────────

// Add Razor Components with interactive server-side rendering (SignalR)
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// SQLite connection string — override via DATABASE_PATH env var in production
var dbPath = builder.Configuration["DATABASE_PATH"] ?? "itdashboard.db";
builder.Services.AddDbContextFactory<AppDbContext>(options =>
    options.UseSqlite($"Data Source={dbPath}"));

// ─── App Pipeline ─────────────────────────────────────────────────────────────

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    // createScopeForErrors: true is required for .NET 8 Blazor Web App so that
    // the error page can access IExceptionHandlerFeature from DI correctly.
    app.UseExceptionHandler("/Error", createScopeForErrors: true);

    // NOTE: HSTS is intentionally omitted — this app runs HTTP-only inside
    // the Docker container. TLS termination is handled by the upstream reverse proxy.
}

app.UseStaticFiles();
app.UseAntiforgery();

// Map Blazor hub and all @page components, enabling Interactive Server mode
app.MapRazorComponents<BlazorDashboard.Components.App>()
    .AddInteractiveServerRenderMode();

// ─── Database Seed ────────────────────────────────────────────────────────────

// Runs synchronously before app.Run() so the DB is fully ready before
// the first request is accepted. EnsureCreatedAsync creates the SQLite file
// and schema if they do not exist; SeedAsync skips tables that already have rows.
using (var scope = app.Services.CreateScope())
{
    var factory = scope.ServiceProvider.GetRequiredService<IDbContextFactory<AppDbContext>>();
    await using var db = await factory.CreateDbContextAsync();
    await db.Database.EnsureCreatedAsync();
    await DbInitializer.SeedAsync(db);
}

app.Run();
