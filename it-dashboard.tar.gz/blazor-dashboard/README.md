# IT Operations Dashboard

An internal IT operations dashboard built with **ASP.NET Core 8 Blazor Web App**. Provides a single-pane-of-glass view for server inventory, service health, and open IT positions. Designed for home-lab and enterprise environments with easy extensibility.

---

## Pages

| Page | Route | Purpose |
|------|-------|---------|
| Dashboard | `/` | KPI widgets, service health summary, open jobs count |
| Server Inventory | `/servers` | Searchable, filterable server table |
| Service Health | `/services` | Monitored service status with response times |
| Job Listings | `/jobs` | Searchable IT job postings filterable by location |
| About | `/about` | Tech stack info and planned integrations |

---

## Tech Stack

- **.NET 8** — Blazor Web App (Interactive Server / SignalR)
- **SQLite** — local development database (seeded automatically on first run)
- **Entity Framework Core 8** — ORM and migrations
- **Bootstrap 5** — responsive admin UI
- **Bootstrap Icons** — icon set
- **Docker** — production container (port 8080)

---

## Local Development

### Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)
- Git

### Run the app

```bash
# Clone / navigate to the project directory
cd blazor-dashboard

# Restore NuGet packages
dotnet restore

# Run in development mode (database is created & seeded automatically)
dotnet run
```

The app will start at **http://localhost:5000** (or the port shown in the terminal).

The SQLite database file `itdashboard.db` is created in the project directory on first run.

### EF Core Migrations (optional)

```bash
# Add a migration
dotnet ef migrations add <MigrationName>

# Apply to the development database
dotnet ef database update
```

---

## Docker Build

### Build the image

```bash
cd blazor-dashboard

docker build -t itdashboard:latest .
```

### Run with Docker directly

```bash
docker run -d \
  -p 8080:8080 \
  -v itdashboard-data:/data \
  --name itdashboard \
  itdashboard:latest
```

App is available at **http://localhost:8080**.

---

## Docker Deployment (Ubuntu Server)

### Prerequisites on the host

```bash
# Install Docker Engine + Compose plugin
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
```

### Deploy

```bash
# Copy the blazor-dashboard directory to the server, then:
cd blazor-dashboard

# Build and start in detached mode
docker compose up -d --build
```

App is available at **http://<server-ip>:8080**.

### Useful commands

```bash
# View logs
docker compose logs -f

# Stop the app
docker compose down

# Stop and remove the data volume (⚠ deletes the database)
docker compose down -v

# Restart after code changes
docker compose up -d --build
```

---

## Required Ports

| Port | Protocol | Purpose |
|------|----------|---------|
| 8080 | TCP | HTTP — main application port (inside container and host mapping) |

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ASPNETCORE_ENVIRONMENT` | `Production` | ASP.NET runtime environment |
| `DATABASE_PATH` | `/data/itdashboard.db` | Path to the SQLite database file |
| `ASPNETCORE_URLS` | `http://+:8080` | Listening URL(s) for the app |

Secrets (AD bind passwords, OIDC client secrets, API keys) should be injected via a `.env` file or Docker secrets — never hardcoded.

Example `.env` file:

```env
ASPNETCORE_ENVIRONMENT=Production
DATABASE_PATH=/data/itdashboard.db
# Future secrets:
# ENTRA_CLIENT_SECRET=...
# DATADOG_API_KEY=...
```

---

## Future Integrations

The dashboard is designed to be extended with:

- **Active Directory / LDAP** — live AD computer and user inventory
- **Entra ID / OIDC** — single sign-on via Microsoft identity
- **Datadog** — real-time metric and alert ingestion
- **Hyper-V** — virtual machine inventory via WMI / REST
- **Certificate Monitoring** — TLS expiry tracking
- **SharePoint Migration Tracking** — migration job progress

Each integration can be added as a new EF Core entity + Blazor page without touching existing code.

---

## Project Structure

```
blazor-dashboard/
├── Components/
│   ├── App.razor                  # Root HTML shell
│   ├── Routes.razor               # Blazor router
│   ├── _Imports.razor             # Global using directives
│   ├── Layout/
│   │   ├── MainLayout.razor       # Shell: sidebar + top bar + content
│   │   ├── NavMenu.razor          # Sidebar (desktop) + offcanvas (mobile)
│   │   └── SidebarContent.razor   # Shared nav links
│   ├── Pages/
│   │   ├── Home.razor             # Dashboard / KPI page
│   │   ├── ServerInventory.razor  # Server table with filters
│   │   ├── ServiceHealthPage.razor# Service health table
│   │   ├── JobListings.razor      # Job cards with location filter
│   │   └── About.razor            # About & tech stack
│   └── Shared/
│       └── StatusBadge.razor      # Reusable status pill component
├── Data/
│   ├── AppDbContext.cs            # EF Core DbContext
│   ├── DbInitializer.cs           # Seed data
│   └── Models/
│       ├── Server.cs
│       ├── ServiceHealth.cs
│       └── Job.cs
├── wwwroot/
│   └── css/site.css               # Custom dashboard styles
├── appsettings.json
├── appsettings.Development.json
├── Program.cs
├── blazor-dashboard.csproj
├── Dockerfile
├── docker-compose.yml
└── .dockerignore
```
