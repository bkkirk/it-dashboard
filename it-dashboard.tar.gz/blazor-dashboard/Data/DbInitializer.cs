using BlazorDashboard.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorDashboard.Data;

/// <summary>
/// Seeds the SQLite database with realistic enterprise / home-lab sample data.
/// Safe to call repeatedly — each table is skipped if it already has rows.
/// </summary>
public static class DbInitializer
{
    public static async Task SeedAsync(AppDbContext db)
    {
        await SeedServersAsync(db);
        await SeedServicesAsync(db);
        await SeedJobsAsync(db);
        await db.SaveChangesAsync();
    }

    // ── Servers ───────────────────────────────────────────────────────────────
    // Naming convention:
    //   <SITE><ROLE><SEQ>.<domain>
    //   Sites: HQ = headquarters, BR1 = Branch 1, DR = disaster recovery
    //   Roles: DC = domain controller, FS = file, DB = database, WEB = web,
    //          APP = application, MAIL = exchange, PKI = cert authority,
    //          MGT = management, MON = monitoring, WSUS = patch, VPN = vpn,
    //          PRT = print, NPS = radius/nps, SCCM = config mgr
    // ─────────────────────────────────────────────────────────────────────────
    private static async Task SeedServersAsync(AppDbContext db)
    {
        if (await db.Servers.AnyAsync()) return;

        db.Servers.AddRange(

            // ── HQ — Identity & Core Infrastructure ─────────────────────────
            new Server
            {
                Hostname = "HQDC01.corp.contoso.com",
                IpAddress = "10.10.1.1",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "Domain Controller / DNS / DHCP",
                Location = "HQ — Rack A1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-730)
            },
            new Server
            {
                Hostname = "HQDC02.corp.contoso.com",
                IpAddress = "10.10.1.2",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "Domain Controller / DNS / DHCP",
                Location = "HQ — Rack A2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-729)
            },
            new Server
            {
                Hostname = "HQPKI01.corp.contoso.com",
                IpAddress = "10.10.1.5",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "PKI / Certificate Authority (Offline Root)",
                Location = "HQ — Vault Rack",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-700)
            },
            new Server
            {
                Hostname = "HQPKI02.corp.contoso.com",
                IpAddress = "10.10.1.6",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "PKI / Issuing CA / OCSP / CRL",
                Location = "HQ — Rack A2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-700)
            },
            new Server
            {
                Hostname = "HQADFS01.corp.contoso.com",
                IpAddress = "10.10.1.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "AD FS / Federation Server",
                Location = "HQ — Rack B1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-540)
            },
            new Server
            {
                Hostname = "HQWAP01.corp.contoso.com",
                IpAddress = "10.10.0.20",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "AD FS Web Application Proxy",
                Location = "HQ — DMZ Rack",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-540)
            },
            new Server
            {
                Hostname = "HQNPS01.corp.contoso.com",
                IpAddress = "10.10.1.15",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "NPS / RADIUS (802.1X + VPN Auth)",
                Location = "HQ — Rack A3",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-600)
            },

            // ── HQ — Messaging ───────────────────────────────────────────────
            new Server
            {
                Hostname = "HQMAIL01.corp.contoso.com",
                IpAddress = "10.10.2.10",
                OperatingSystem = "Windows Server 2019 Standard",
                Role = "Exchange Server 2019 — Mailbox",
                Location = "HQ — Rack C1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-480)
            },
            new Server
            {
                Hostname = "HQMAIL02.corp.contoso.com",
                IpAddress = "10.10.2.11",
                OperatingSystem = "Windows Server 2019 Standard",
                Role = "Exchange Server 2019 — Mailbox (DAG)",
                Location = "HQ — Rack C2",
                Status = "Degraded",
                AddedDate = DateTime.UtcNow.AddDays(-480)
            },
            new Server
            {
                Hostname = "HQSMTP01.corp.contoso.com",
                IpAddress = "10.10.0.25",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "Postfix SMTP Relay / Anti-Spam (DMZ)",
                Location = "HQ — DMZ Rack",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-400)
            },

            // ── HQ — File, Print & Collaboration ─────────────────────────────
            new Server
            {
                Hostname = "HQFS01.corp.contoso.com",
                IpAddress = "10.10.3.10",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "DFS File Server — Namespace Root",
                Location = "HQ — Rack D1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-650)
            },
            new Server
            {
                Hostname = "HQFS02.corp.contoso.com",
                IpAddress = "10.10.3.11",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "DFS File Server — Replication Target",
                Location = "HQ — Rack D2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-648)
            },
            new Server
            {
                Hostname = "HQPRT01.corp.contoso.com",
                IpAddress = "10.10.3.20",
                OperatingSystem = "Windows Server 2019 Standard",
                Role = "Print Server (Universal Print Gateway)",
                Location = "HQ — Rack D3",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-500)
            },
            new Server
            {
                Hostname = "HQSP01.corp.contoso.com",
                IpAddress = "10.10.3.30",
                OperatingSystem = "Windows Server 2019 Standard",
                Role = "SharePoint Server 2019 — Front-End",
                Location = "HQ — Rack E1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-365)
            },

            // ── HQ — Database & Application ───────────────────────────────────
            new Server
            {
                Hostname = "HQDB01.corp.contoso.com",
                IpAddress = "10.10.4.10",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "SQL Server 2022 — AG Primary",
                Location = "HQ — Rack E2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-600)
            },
            new Server
            {
                Hostname = "HQDB02.corp.contoso.com",
                IpAddress = "10.10.4.11",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "SQL Server 2022 — AG Secondary",
                Location = "HQ — Rack E3",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-600)
            },
            new Server
            {
                Hostname = "HQDB03.corp.contoso.com",
                IpAddress = "10.10.4.12",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "PostgreSQL 16 — Internal Apps DB",
                Location = "HQ — Rack E3",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-200)
            },
            new Server
            {
                Hostname = "HQAPP01.corp.contoso.com",
                IpAddress = "10.10.5.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "IIS App Server — Internal .NET Applications",
                Location = "HQ — Rack F1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-300)
            },
            new Server
            {
                Hostname = "HQAPP02.corp.contoso.com",
                IpAddress = "10.10.5.11",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "Docker Host — Containerised Microservices",
                Location = "HQ — Rack F2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-180)
            },

            // ── HQ — Management, Monitoring & Patching ────────────────────────
            new Server
            {
                Hostname = "HQMGT01.corp.contoso.com",
                IpAddress = "10.10.6.5",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "Jump Server / PAW (Privileged Access Workstation)",
                Location = "HQ — Rack G1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-400)
            },
            new Server
            {
                Hostname = "HQSCCM01.corp.contoso.com",
                IpAddress = "10.10.6.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "MECM / SCCM — Site Server & SUP",
                Location = "HQ — Rack G1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-450)
            },
            new Server
            {
                Hostname = "HQWSUS01.corp.contoso.com",
                IpAddress = "10.10.6.15",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "WSUS — Windows Update Distribution",
                Location = "HQ — Rack G2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-600)
            },
            new Server
            {
                Hostname = "HQMON01.corp.contoso.com",
                IpAddress = "10.10.6.20",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "Zabbix Server / Grafana / InfluxDB",
                Location = "HQ — Rack G2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-360)
            },
            new Server
            {
                Hostname = "HQSIEM01.corp.contoso.com",
                IpAddress = "10.10.6.25",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "Wazuh SIEM / Log Aggregation",
                Location = "HQ — Rack G3",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-220)
            },
            new Server
            {
                Hostname = "HQVPN01.corp.contoso.com",
                IpAddress = "10.10.0.10",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "OpenVPN Access Server / SSTP Endpoint",
                Location = "HQ — DMZ Rack",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-500)
            },
            new Server
            {
                Hostname = "HQBKP01.corp.contoso.com",
                IpAddress = "10.10.7.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "Veeam Backup & Replication Server",
                Location = "HQ — Rack H1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-550)
            },
            new Server
            {
                Hostname = "HQBKP02.corp.contoso.com",
                IpAddress = "10.10.7.11",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "Veeam Backup Repository (Scale-Out)",
                Location = "HQ — Rack H2",
                Status = "Degraded",
                AddedDate = DateTime.UtcNow.AddDays(-549)
            },

            // ── Branch 1 (BR1) — Minimal Site Stack ───────────────────────────
            new Server
            {
                Hostname = "BR1DC01.corp.contoso.com",
                IpAddress = "10.20.1.1",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "RODC / DNS / DHCP",
                Location = "BR1 — Server Room Rack 1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-400)
            },
            new Server
            {
                Hostname = "BR1FS01.corp.contoso.com",
                IpAddress = "10.20.3.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "DFS File Server — Replication Target",
                Location = "BR1 — Server Room Rack 1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-398)
            },
            new Server
            {
                Hostname = "BR1APP01.corp.contoso.com",
                IpAddress = "10.20.5.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "Branch App / RDS Session Host",
                Location = "BR1 — Server Room Rack 2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-350)
            },

            // ── DR Site — Disaster Recovery ───────────────────────────────────
            new Server
            {
                Hostname = "DRDC01.corp.contoso.com",
                IpAddress = "10.30.1.1",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "Domain Controller / DNS / DHCP (DR)",
                Location = "DR — Colocation Cage 1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-500)
            },
            new Server
            {
                Hostname = "DRDB01.corp.contoso.com",
                IpAddress = "10.30.4.10",
                OperatingSystem = "Windows Server 2022 Datacenter",
                Role = "SQL Server 2022 — AG DR Replica (Async)",
                Location = "DR — Colocation Cage 1",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-498)
            },
            new Server
            {
                Hostname = "DRBKP01.corp.contoso.com",
                IpAddress = "10.30.7.10",
                OperatingSystem = "Windows Server 2022 Standard",
                Role = "Veeam Cloud Connect Repository (DR Target)",
                Location = "DR — Colocation Cage 2",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-490)
            },

            // ── DMZ / Edge ────────────────────────────────────────────────────
            new Server
            {
                Hostname = "HQRPX01.corp.contoso.com",
                IpAddress = "10.10.0.30",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "NGINX Reverse Proxy / WAF (ModSecurity)",
                Location = "HQ — DMZ Rack",
                Status = "Online",
                AddedDate = DateTime.UtcNow.AddDays(-300)
            },
            new Server
            {
                Hostname = "HQRPX02.corp.contoso.com",
                IpAddress = "10.10.0.31",
                OperatingSystem = "Ubuntu 22.04 LTS",
                Role = "NGINX Reverse Proxy — HA Standby",
                Location = "HQ — DMZ Rack",
                Status = "Offline",
                AddedDate = DateTime.UtcNow.AddDays(-300)
            }
        );
    }

    // ── Service Health ────────────────────────────────────────────────────────
    // Covers identity, network, messaging, databases, collaboration,
    // security, backup, and monitoring tiers.
    // ─────────────────────────────────────────────────────────────────────────
    private static async Task SeedServicesAsync(AppDbContext db)
    {
        if (await db.ServiceHealthRecords.AnyAsync()) return;

        db.ServiceHealthRecords.AddRange(

            // Identity & Directory
            new ServiceHealth
            {
                ServiceName = "Active Directory DS (HQ)",
                Category = "Identity",
                Status = "Healthy",
                Endpoint = "ldap://HQDC01.corp.contoso.com:389",
                ResponseTimeMs = 8,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Active Directory DS (BR1 — RODC)",
                Category = "Identity",
                Status = "Healthy",
                Endpoint = "ldap://BR1DC01.corp.contoso.com:389",
                ResponseTimeMs = 22,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "AD FS — Federation Service",
                Category = "Identity",
                Status = "Healthy",
                Endpoint = "https://sts.contoso.com/adfs/ls",
                ResponseTimeMs = 95,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Entra ID Connect Sync",
                Category = "Identity",
                Status = "Degraded",
                Endpoint = "HQDC01.corp.contoso.com — ADSync Service",
                ResponseTimeMs = null,
                LastChecked = DateTime.UtcNow.AddMinutes(-8),
                Message = "Delta sync cycle missed — last successful sync 47 min ago"
            },
            new ServiceHealth
            {
                ServiceName = "NPS / RADIUS (802.1X)",
                Category = "Identity",
                Status = "Healthy",
                Endpoint = "HQNPS01.corp.contoso.com:1812",
                ResponseTimeMs = 11,
                LastChecked = DateTime.UtcNow.AddMinutes(-3),
                Message = null
            },

            // Network & DNS
            new ServiceHealth
            {
                ServiceName = "DNS — HQ Primary (HQDC01)",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "10.10.1.1:53",
                ResponseTimeMs = 3,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "DNS — HQ Secondary (HQDC02)",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "10.10.1.2:53",
                ResponseTimeMs = 4,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "DNS — Branch 1 (BR1DC01)",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "10.20.1.1:53",
                ResponseTimeMs = 14,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "DHCP — HQ Scope (10.10.0.0/16)",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "HQDC01.corp.contoso.com:67",
                ResponseTimeMs = 6,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "VPN — OpenVPN Access Server",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "vpn.contoso.com:1194",
                ResponseTimeMs = 42,
                LastChecked = DateTime.UtcNow.AddMinutes(-3),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "VPN — SSTP Gateway",
                Category = "Network",
                Status = "Unhealthy",
                Endpoint = "vpn.contoso.com:443/sstp",
                ResponseTimeMs = null,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = "SSL certificate expired 2 days ago — renew via HQPKI02"
            },
            new ServiceHealth
            {
                ServiceName = "NGINX Reverse Proxy (Primary)",
                Category = "Network",
                Status = "Healthy",
                Endpoint = "https://HQRPX01.corp.contoso.com",
                ResponseTimeMs = 18,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "NGINX Reverse Proxy (Standby)",
                Category = "Network",
                Status = "Unhealthy",
                Endpoint = "https://HQRPX02.corp.contoso.com",
                ResponseTimeMs = null,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = "Host unreachable — HQRPX02 is offline for planned maintenance"
            },

            // PKI & Certificates
            new ServiceHealth
            {
                ServiceName = "PKI — Issuing CA (HQPKI02)",
                Category = "PKI",
                Status = "Healthy",
                Endpoint = "http://pki.corp.contoso.com/CertEnroll",
                ResponseTimeMs = 60,
                LastChecked = DateTime.UtcNow.AddMinutes(-10),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "PKI — OCSP Responder",
                Category = "PKI",
                Status = "Healthy",
                Endpoint = "http://ocsp.corp.contoso.com:80",
                ResponseTimeMs = 33,
                LastChecked = DateTime.UtcNow.AddMinutes(-10),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "PKI — CRL Distribution Point",
                Category = "PKI",
                Status = "Healthy",
                Endpoint = "http://pki.corp.contoso.com/crl/root.crl",
                ResponseTimeMs = 28,
                LastChecked = DateTime.UtcNow.AddMinutes(-15),
                Message = null
            },

            // Messaging
            new ServiceHealth
            {
                ServiceName = "Exchange 2019 — OWA / ECP",
                Category = "Messaging",
                Status = "Healthy",
                Endpoint = "https://mail.contoso.com/owa",
                ResponseTimeMs = 220,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Exchange 2019 — ActiveSync",
                Category = "Messaging",
                Status = "Healthy",
                Endpoint = "https://mail.contoso.com/Microsoft-Server-ActiveSync",
                ResponseTimeMs = 190,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Exchange 2019 — HQMAIL02 DAG Node",
                Category = "Messaging",
                Status = "Degraded",
                Endpoint = "HQMAIL02.corp.contoso.com — MSExchangeRepl",
                ResponseTimeMs = null,
                LastChecked = DateTime.UtcNow.AddMinutes(-6),
                Message = "DAG replication suspended — manual intervention required"
            },
            new ServiceHealth
            {
                ServiceName = "SMTP Relay (Postfix / DMZ)",
                Category = "Messaging",
                Status = "Healthy",
                Endpoint = "HQSMTP01.corp.contoso.com:25",
                ResponseTimeMs = 48,
                LastChecked = DateTime.UtcNow.AddMinutes(-4),
                Message = null
            },

            // Database
            new ServiceHealth
            {
                ServiceName = "SQL Server AG — Primary (HQDB01)",
                Category = "Database",
                Status = "Healthy",
                Endpoint = "HQDB01.corp.contoso.com:1433",
                ResponseTimeMs = 12,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "SQL Server AG — Secondary (HQDB02)",
                Category = "Database",
                Status = "Healthy",
                Endpoint = "HQDB02.corp.contoso.com:1433",
                ResponseTimeMs = 15,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "SQL Server AG — DR Replica (DRDB01)",
                Category = "Database",
                Status = "Healthy",
                Endpoint = "DRDB01.corp.contoso.com:1433",
                ResponseTimeMs = 61,
                LastChecked = DateTime.UtcNow.AddMinutes(-3),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "PostgreSQL 16 (HQDB03)",
                Category = "Database",
                Status = "Healthy",
                Endpoint = "HQDB03.corp.contoso.com:5432",
                ResponseTimeMs = 9,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },

            // File & Collaboration
            new ServiceHealth
            {
                ServiceName = "DFS Namespace (\\\\corp.contoso.com\\shares)",
                Category = "Storage",
                Status = "Healthy",
                Endpoint = "\\\\HQFS01.corp.contoso.com",
                ResponseTimeMs = 19,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "DFS Replication — HQ ↔ BR1",
                Category = "Storage",
                Status = "Degraded",
                Endpoint = "HQFS01 ↔ BR1FS01 — DFS-R",
                ResponseTimeMs = null,
                LastChecked = DateTime.UtcNow.AddMinutes(-15),
                Message = "Backlog: 3,412 files pending replication to BR1FS01"
            },
            new ServiceHealth
            {
                ServiceName = "SharePoint 2019 — Intranet",
                Category = "Collaboration",
                Status = "Healthy",
                Endpoint = "https://intranet.corp.contoso.com",
                ResponseTimeMs = 340,
                LastChecked = DateTime.UtcNow.AddMinutes(-3),
                Message = null
            },

            // Endpoint Management & Patching
            new ServiceHealth
            {
                ServiceName = "MECM/SCCM — SMS Agent Host",
                Category = "Endpoint Mgmt",
                Status = "Healthy",
                Endpoint = "HQSCCM01.corp.contoso.com:8530",
                ResponseTimeMs = 75,
                LastChecked = DateTime.UtcNow.AddMinutes(-10),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "WSUS — Update Distribution",
                Category = "Endpoint Mgmt",
                Status = "Degraded",
                Endpoint = "http://HQWSUS01.corp.contoso.com:8530",
                ResponseTimeMs = 1840,
                LastChecked = DateTime.UtcNow.AddMinutes(-10),
                Message = "Slow response — synchronisation with Microsoft Update in progress"
            },

            // Security
            new ServiceHealth
            {
                ServiceName = "Wazuh SIEM — Manager",
                Category = "Security",
                Status = "Healthy",
                Endpoint = "HQSIEM01.corp.contoso.com:1515",
                ResponseTimeMs = 30,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Wazuh — Kibana / Dashboard",
                Category = "Security",
                Status = "Healthy",
                Endpoint = "https://HQSIEM01.corp.contoso.com:443",
                ResponseTimeMs = 280,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = null
            },

            // Monitoring & Observability
            new ServiceHealth
            {
                ServiceName = "Zabbix Server",
                Category = "Monitoring",
                Status = "Healthy",
                Endpoint = "http://HQMON01.corp.contoso.com:10051",
                ResponseTimeMs = 22,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Grafana Dashboard",
                Category = "Monitoring",
                Status = "Healthy",
                Endpoint = "https://HQMON01.corp.contoso.com:3000",
                ResponseTimeMs = 110,
                LastChecked = DateTime.UtcNow.AddMinutes(-1),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "InfluxDB (Metrics Store)",
                Category = "Monitoring",
                Status = "Healthy",
                Endpoint = "http://HQMON01.corp.contoso.com:8086",
                ResponseTimeMs = 14,
                LastChecked = DateTime.UtcNow.AddMinutes(-2),
                Message = null
            },

            // Backup
            new ServiceHealth
            {
                ServiceName = "Veeam B&R — Backup Server",
                Category = "Backup",
                Status = "Healthy",
                Endpoint = "HQBKP01.corp.contoso.com:9392",
                ResponseTimeMs = 55,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = null
            },
            new ServiceHealth
            {
                ServiceName = "Veeam — Scale-Out Repository (HQBKP02)",
                Category = "Backup",
                Status = "Degraded",
                Endpoint = "HQBKP02.corp.contoso.com — VeeamTransportSvc",
                ResponseTimeMs = 1200,
                LastChecked = DateTime.UtcNow.AddMinutes(-5),
                Message = "Repository disk usage at 91% — capacity alert active"
            },
            new ServiceHealth
            {
                ServiceName = "Veeam Cloud Connect — DR Site",
                Category = "Backup",
                Status = "Healthy",
                Endpoint = "DRBKP01.corp.contoso.com:6180",
                ResponseTimeMs = 88,
                LastChecked = DateTime.UtcNow.AddMinutes(-6),
                Message = null
            }
        );
    }

    // ── Job Listings ──────────────────────────────────────────────────────────
    // Realistic IT roles across operations, infrastructure, cloud, security,
    // dev, and support. Mix of full-time, part-time, and contract.
    // ─────────────────────────────────────────────────────────────────────────
    private static async Task SeedJobsAsync(AppDbContext db)
    {
        if (await db.Jobs.AnyAsync()) return;

        db.Jobs.AddRange(

            new Job
            {
                Title = "Senior Systems Administrator — Windows",
                Department = "IT Operations",
                Location = "New York, NY",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-4),
                Description =
                    "We are looking for an experienced Windows Systems Administrator to own our " +
                    "on-premises server estate. Responsibilities include administration of Active Directory " +
                    "Domain Services, Group Policy, DNS, DHCP, AD CS, and AD FS across multiple sites. " +
                    "You will manage Hyper-V clusters, coordinate patch cycles via MECM, and maintain " +
                    "our Exchange 2019 DAG environment. Experience with Entra ID Connect sync, " +
                    "conditional access, and hybrid identity is strongly preferred. Must be comfortable " +
                    "working within a PAW / tiered administration model. MCSA/MCSE or equivalent " +
                    "professional certification required. Salary: $95,000–$120,000."
            },
            new Job
            {
                Title = "Linux Systems Administrator (Ubuntu / RHEL)",
                Department = "IT Operations",
                Location = "Chicago, IL",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-11),
                Description =
                    "Join the infrastructure team responsible for our growing Linux server footprint. " +
                    "Day-to-day duties include managing Ubuntu 22.04 and RHEL 9 systems, administering " +
                    "Nginx, Postfix, and Docker hosts, and maintaining Ansible playbooks for configuration " +
                    "drift remediation. You will support the Zabbix/Grafana monitoring stack and own " +
                    "the on-call rota for Linux-hosted services. Familiarity with systemd, LVM, " +
                    "SELinux/AppArmor, and scripting in Bash or Python is essential. RHCSA preferred. " +
                    "Salary: $88,000–$110,000."
            },
            new Job
            {
                Title = "Network Engineer — Cisco / Juniper",
                Department = "Infrastructure",
                Location = "New York, NY",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-7),
                Description =
                    "Design, implement, and support the LAN/WAN/SD-WAN network spanning headquarters, " +
                    "Branch 1, and our DR colocation facility. You will configure and troubleshoot " +
                    "Cisco Catalyst and Nexus switches, ASA/FTD firewalls, and ISR/ASR routers, and " +
                    "manage BGP, OSPF, and MPLS circuits. Responsibilities include 802.1X NAC policy " +
                    "via NPS, QoS tuning for VoIP, and SD-WAN overlay management. Cisco CCNP Enterprise " +
                    "or CCNP Security required; CCIE preferred. Salary: $105,000–$135,000."
            },
            new Job
            {
                Title = "Cloud Infrastructure Engineer — Azure",
                Department = "Cloud & DevOps",
                Location = "Remote",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-2),
                Description =
                    "Own and evolve our Azure IaaS and PaaS footprint. You will design landing zones " +
                    "with Azure Policy and Management Groups, provision resources using Terraform and " +
                    "Bicep, and maintain Azure DevOps CI/CD pipelines. Key workloads include Azure " +
                    "Virtual Desktop, AKS, Azure SQL Managed Instance, and Defender for Cloud. " +
                    "You will partner with the identity team on Entra ID governance, PIM, and " +
                    "conditional access. AZ-104 required; AZ-305 or AZ-400 preferred. " +
                    "Salary: $115,000–$145,000."
            },
            new Job
            {
                Title = "DevOps / Platform Engineer",
                Department = "Cloud & DevOps",
                Location = "Remote",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-9),
                Description =
                    "Build and maintain the internal developer platform. You will run our Kubernetes " +
                    "clusters (AKS + on-prem k3s), manage Helm chart libraries, and operate the " +
                    "Azure DevOps / GitHub Actions CI/CD ecosystem. Responsibilities include container " +
                    "image hardening, secret management with Azure Key Vault and Vault by HashiCorp, " +
                    "and platform SLO ownership. Strong Dockerfile authorship, GitOps experience with " +
                    "Flux or ArgoCD, and proficiency in Go or Python required. " +
                    "Salary: $120,000–$150,000."
            },
            new Job
            {
                Title = "Infrastructure Automation Engineer (Contract)",
                Department = "Cloud & DevOps",
                Location = "Remote",
                EmploymentType = "Contract",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-5),
                Description =
                    "12-month contract to automate on-premises infrastructure provisioning. " +
                    "You will extend existing Ansible roles for Windows and Linux, build DSC " +
                    "configurations for Windows workloads, and integrate both into Azure DevOps " +
                    "pipelines. Deliverables include an IPAM-integrated server provisioning pipeline " +
                    "and automated WSUS approval workflows. Experience with PowerShell 7, Ansible, " +
                    "and Git required. Day rate: $600–$750."
            },
            new Job
            {
                Title = "IT Security Analyst — Tier 2",
                Department = "Cybersecurity",
                Location = "Austin, TX",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-14),
                Description =
                    "Triage and investigate alerts from our Wazuh SIEM and Microsoft Defender XDR " +
                    "environment. You will perform host-based forensics, lead incident response " +
                    "tabletops, and track vulnerabilities through to remediation using Tenable.io. " +
                    "Additional responsibilities include threat hunting, phishing analysis, and " +
                    "maintaining the security runbook library. CompTIA Security+ and CySA+ (or " +
                    "equivalent) required; CEH or GCIA preferred. Salary: $90,000–$115,000."
            },
            new Job
            {
                Title = "Identity & Access Management Engineer",
                Department = "Cybersecurity",
                Location = "New York, NY",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-20),
                Description =
                    "Own the enterprise IAM programme spanning on-premises Active Directory, " +
                    "Entra ID, and AD FS. You will design and implement role-based access control, " +
                    "privileged identity management (PIM), just-in-time access policies, and " +
                    "Conditional Access. Project deliverables include migration of legacy NTLM " +
                    "applications to Kerberos/SAML and a self-service password reset rollout. " +
                    "Deep knowledge of LDAP, Kerberos, OAuth 2.0, and OIDC required. " +
                    "SC-300 or equivalent certification preferred. Salary: $110,000–$135,000."
            },
            new Job
            {
                Title = "PKI / Certificate Lifecycle Engineer",
                Department = "Cybersecurity",
                Location = "Austin, TX",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-6),
                Description =
                    "Responsible for the full lifecycle of our two-tier Microsoft AD CS PKI hierarchy " +
                    "and third-party public certificates. Duties include CA health monitoring, " +
                    "CRL/OCSP availability, certificate template management, and auto-enrollment " +
                    "policy. You will implement certificate transparency logging, drive adoption of " +
                    "short-lived certificates, and own the DigiCert account for public TLS. " +
                    "Familiarity with ACME (Let's Encrypt / cert-manager) a bonus. " +
                    "Salary: $95,000–$120,000."
            },
            new Job
            {
                Title = "Database Administrator — SQL Server & PostgreSQL",
                Department = "Data & Analytics",
                Location = "Chicago, IL",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-25),
                Description =
                    "Administer SQL Server 2022 Always On Availability Groups across three nodes " +
                    "(HQ Primary, HQ Secondary, DR Async Replica) and a PostgreSQL 16 instance " +
                    "hosting internal application databases. Responsibilities include performance " +
                    "tuning, index maintenance, backup verification, capacity planning, and " +
                    "schema review for development teams. Experience with Query Store, Extended " +
                    "Events, pg_stat_statements, and logical replication required. " +
                    "Salary: $100,000–$125,000."
            },
            new Job
            {
                Title = "Data Engineer — Azure Synapse & Databricks",
                Department = "Data & Analytics",
                Location = "Remote",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-3),
                Description =
                    "Build and maintain data pipelines that ingest from on-premises SQL Server " +
                    "and SaaS platforms into Azure Data Lake Gen2, transform via Azure Synapse " +
                    "Analytics, and serve to Databricks notebooks and Power BI. You will own " +
                    "medallion architecture design, Delta Lake compaction, and pipeline " +
                    "monitoring. Proficiency in PySpark, SQL, Azure Data Factory, and Git " +
                    "required. DP-203 certification preferred. Salary: $105,000–$130,000."
            },
            new Job
            {
                Title = "IT Project Manager — Infrastructure",
                Department = "IT Operations",
                Location = "Chicago, IL",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-30),
                Description =
                    "Lead concurrent infrastructure projects including an Exchange Online migration, " +
                    "a WAN SD-WAN overlay uplift, and a server refresh programme. You will manage " +
                    "project plans in Azure DevOps Boards, track risks and dependencies, and " +
                    "present status to senior leadership. Experience managing technical IT projects " +
                    "end-to-end is essential. PMP or PRINCE2 Practitioner required; " +
                    "ITIL 4 Foundation preferred. Salary: $100,000–$120,000."
            },
            new Job
            {
                Title = "IT Service Desk Analyst — Tier 2",
                Department = "IT Support",
                Location = "New York, NY",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-1),
                Description =
                    "Provide second-line desktop and application support to 800+ staff across " +
                    "headquarters and Branch 1. You will resolve escalations from Tier 1 covering " +
                    "Windows 11, Microsoft 365, VPN (OpenVPN and SSTP), and line-of-business " +
                    "applications. Additional duties include laptop imaging via MECM task sequence, " +
                    "BitLocker key recovery, and AD account administration. Experience with ITSM " +
                    "ticketing (ServiceNow or Jira Service Management) required. " +
                    "Salary: $55,000–$70,000."
            },
            new Job
            {
                Title = "IT Support Specialist — Part-time",
                Department = "IT Support",
                Location = "Austin, TX",
                EmploymentType = "Part-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-8),
                Description =
                    "Part-time (20 hrs/week) on-site IT support for the Austin office. " +
                    "Responsibilities include hardware break/fix, peripheral setup, " +
                    "meeting room AV troubleshooting, and new-starter onboarding assistance. " +
                    "CompTIA A+ or equivalent experience preferred. Salary: $28–$35/hr."
            },
            new Job
            {
                Title = "Backup & Disaster Recovery Engineer",
                Department = "Infrastructure",
                Location = "New York, NY",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-17),
                Description =
                    "Own the organisation's backup and DR strategy using Veeam Backup & " +
                    "Replication. Responsibilities include managing backup jobs, scale-out " +
                    "repository capacity, Cloud Connect replication to the DR colocation site, " +
                    "and monthly restore test documentation. You will own the DR run-book and " +
                    "coordinate failover exercises for critical SQL Server and Exchange workloads. " +
                    "Experience with Veeam v12, HPE/Dell storage, and BCDR planning required. " +
                    "Salary: $90,000–$110,000."
            },
            new Job
            {
                Title = "Monitoring & Observability Engineer",
                Department = "Infrastructure",
                Location = "Remote",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-13),
                Description =
                    "Own and evolve the observability stack: Zabbix for infrastructure monitoring, " +
                    "Grafana + InfluxDB for metrics dashboards, and Wazuh for log aggregation and " +
                    "alerting. You will build host and service templates, define SLI/SLO baselines, " +
                    "integrate Datadog for APM on cloud workloads, and operate the on-call paging " +
                    "workflow via PagerDuty. Proficiency in SNMP, JMX, Prometheus exporters, and " +
                    "PromQL is required. Salary: $95,000–$120,000."
            },
            new Job
            {
                Title = "Microsoft 365 & Exchange Online Administrator",
                Department = "IT Operations",
                Location = "Chicago, IL",
                EmploymentType = "Full-time",
                IsActive = true,
                PostedDate = DateTime.UtcNow.AddDays(-22),
                Description =
                    "Administer the Microsoft 365 tenant during and after a hybrid Exchange to " +
                    "Exchange Online migration. Responsibilities include mailbox moves, mail flow " +
                    "rule migration, Teams telephony configuration, SharePoint Online governance, " +
                    "and Defender for Office 365 policy tuning. You will maintain the hybrid " +
                    "connector and coexistence configuration until cutover is complete. " +
                    "MS-203 or MS-102 certification preferred. Salary: $80,000–$100,000."
            }
        );
    }
}
