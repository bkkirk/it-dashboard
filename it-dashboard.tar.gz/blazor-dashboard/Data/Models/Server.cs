namespace BlazorDashboard.Data.Models;

/// <summary>
/// Represents a physical or virtual server tracked in the inventory.
/// </summary>
public class Server
{
    public int Id { get; set; }

    /// <summary>Hostname / FQDN of the server.</summary>
    public string Hostname { get; set; } = string.Empty;

    /// <summary>IP address (IPv4 or IPv6).</summary>
    public string IpAddress { get; set; } = string.Empty;

    /// <summary>Operating system name and version.</summary>
    public string OperatingSystem { get; set; } = string.Empty;

    /// <summary>Role the server fills, e.g. Web, Database, DNS.</summary>
    public string Role { get; set; } = string.Empty;

    /// <summary>Physical or virtual data centre / location.</summary>
    public string Location { get; set; } = string.Empty;

    /// <summary>Current operational status.</summary>
    public string Status { get; set; } = "Online";

    /// <summary>Date the server was added to inventory.</summary>
    public DateTime AddedDate { get; set; } = DateTime.UtcNow;
}
