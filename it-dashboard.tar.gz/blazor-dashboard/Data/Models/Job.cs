namespace BlazorDashboard.Data.Models;

/// <summary>
/// Represents an open IT job listing.
/// </summary>
public class Job
{
    public int Id { get; set; }

    /// <summary>Job title / position name.</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>Department the role belongs to.</summary>
    public string Department { get; set; } = string.Empty;

    /// <summary>Office / work location.</summary>
    public string Location { get; set; } = string.Empty;

    /// <summary>Full description of duties and requirements.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>Employment type: Full-time, Part-time, Contract.</summary>
    public string EmploymentType { get; set; } = "Full-time";

    /// <summary>Whether the listing is currently accepting applications.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Date the posting was created.</summary>
    public DateTime PostedDate { get; set; } = DateTime.UtcNow;
}
