namespace BlazorDashboard.Data.Models;

/// <summary>
/// Tracks health / status of a monitored service or application.
/// </summary>
public class ServiceHealth
{
    public int Id { get; set; }

    /// <summary>Human-readable service name.</summary>
    public string ServiceName { get; set; } = string.Empty;

    /// <summary>Category, e.g. Web, Database, Network, Identity.</summary>
    public string Category { get; set; } = string.Empty;

    /// <summary>Health status: Healthy, Degraded, Unhealthy, Unknown.</summary>
    public string Status { get; set; } = "Unknown";

    /// <summary>URL or endpoint being monitored.</summary>
    public string Endpoint { get; set; } = string.Empty;

    /// <summary>Last time the service health was checked.</summary>
    public DateTime LastChecked { get; set; } = DateTime.UtcNow;

    /// <summary>Optional human-readable message or error detail.</summary>
    public string? Message { get; set; }

    /// <summary>Response time in milliseconds from the last check.</summary>
    public int? ResponseTimeMs { get; set; }
}
