using BlazorDashboard.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorDashboard.Data;

/// <summary>
/// Entity Framework Core database context for the IT Dashboard.
/// Registered as a factory (IDbContextFactory) so Blazor components
/// can safely create short-lived scopes per operation.
/// </summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Server> Servers => Set<Server>();
    public DbSet<ServiceHealth> ServiceHealthRecords => Set<ServiceHealth>();
    public DbSet<Job> Jobs => Set<Job>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Index on Status for quick filtering on dashboard widgets
        modelBuilder.Entity<Server>()
            .HasIndex(s => s.Status);

        modelBuilder.Entity<ServiceHealth>()
            .HasIndex(s => s.Status);

        modelBuilder.Entity<Job>()
            .HasIndex(j => j.Location);

        modelBuilder.Entity<Job>()
            .HasIndex(j => j.IsActive);
    }
}
